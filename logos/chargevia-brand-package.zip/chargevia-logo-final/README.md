# ChargeVia Logo Package

## Files Included

### Icons
- `icon.svg` — Primary icon (black container) for light backgrounds
- `icon-white.svg` — White container version for dark backgrounds
- `icon-mono.svg` — Single-color version for limited color applications

### Lockups
- `lockup.svg` — Full logo for light backgrounds
- `lockup-dark.svg` — Full logo for dark backgrounds

## Specifications

### Icon
- Container: True Black #111111
- Corner radius: 16px (in 80×80 viewBox)
- Chevron stroke: 9px
- Chevron angle: 90° (wider, relaxed)

### Colors
- **Charge Orange:** #FF6B35 (gradient to #E85A24)
- **Power Purple:** #8B6BB4 (gradient to #7B5BA4)
- **Container Black:** #111111
- **Text Dark:** #111111

### Typography
- Font: Outfit Bold (700)
- "Charge" in #111111 (light bg) or #FFFFFF (dark bg)
- "Via" always in #FF6B35

## Usage Guidelines

### Light Backgrounds
Use `icon.svg` or `lockup.svg`

### Dark Backgrounds
Use `icon.svg` with subtle border, `icon-white.svg`, or `lockup-dark.svg`

### Minimum Size
- Icon: 16px
- Lockup: 120px wide

### Clear Space
Maintain minimum clear space equal to the height of one chevron around the logo.

### Do Not
- Use the old Asphalt (#2C3E50) as container color
- Stretch or distort the logo
- Change the chevron colors
- Add effects like drop shadows or glows
